//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDD_LIST                        101
#define IDR_MENU1                       102
#define IDD_SERVER                      104
#define IDD_CHANNEL                     105
#define IDD_SETTINGS                    106
#define IDD_SERVER_LIST                 107
#define IDD_CUSTOM_RESOURCE             109
#define IDD_USER_INPUT                  110
#define IDD_TEXTSEARCH                  111
#define IDD_MESSAGEBOX                  112
#define IDD_CHANNELMODES                113
#define IDI_ICON                        115
#define IDC_ADD                         1002
#define IDC_DELETE                      1003
#define IDC_EDIT                        1005
#define IDC_NETWORK                     1007
#define IDC_SERVER                      1008
#define IDC_QUIT_MSG                    1008
#define MDI_EDIT                        1008
#define IDC_SSL                         1009
#define IDC_PORTS                       1010
#define IDC_CHANNEL                     1013
#define IDC_JOIN                        1014
#define IDC_NICK                        1015
#define IDC_JOIN_CONNECT                1017
#define MDI_LIST                        1018
#define IDC_SERVER_LIST                 1022
#define IDC_OPENINI                     1023
#define IDC_CONNECT_STARTUP             1024
#define MDI_STATIC                      1025
#define IDC_SWITCHBAR                   1027
#define IDC_MDI_CLIENT                  1028
#define SERVER_WINDOW                   1029
#define CHANNEL_WINDOW                  1030
#define PRIVMSG_WINDOW                  1031
#define IDC_SWITCHBUTTON                1032
#define IDC_USER_EDIT                   1033
#define IDC_ADD_BUTTON                  1034
#define IDC_PASSWORD                    1035
#define IDC_LISTVIEW                    1037
#define IDC_SHOWJOINS                   1038
#define IDC_WORDWATCH                   1039
#define IDC_SEARCH_UP                   1040
#define IDC_SEARCH_DOWN                 1041
#define IDC_SEARCH_BOX                  1042
#define IDC_MESSAGETEXT                 1043
#define IDC_USERNAME                    1044
#define IDC_REALNAME                    1045
#define IDC_TOPIC                       1046
#define IDC_BANLIST                     1047
#define IDC_ONLYOPS                     1048
#define IDC_NOEXTERNAL                  1049
#define IDC_INVITEONLY                  1050
#define IDC_MODERATED                   1051
#define IDC_REQUIRESKEY                 1052
#define IDC_LIMITTO                     1053
#define IDC_PRIVATE                     1054
#define IDC_SECRET                      1055
#define IDC_KEY                         1056
#define IDC_USERS                       1057
#define IDC_STATIC1                     1058
#define IDC_ENABLELOG                   1059
#define IDC_DEBUG                       1060
#define IDC_POSTCONNECT                 1061
#define IDC_STATIC_PCC                  1062
#define ID_SERVERS                      40001
#define ID_CHANNELS                     40003
#define ID_CONNECT                      40006
#define ID_SETTINGS                     40007
#define ID_WINDOW_LIST                  40008
#define ID_DISCONNECT                   40009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        116
#define _APS_NEXT_COMMAND_VALUE         40011
#define _APS_NEXT_CONTROL_VALUE         1063
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
