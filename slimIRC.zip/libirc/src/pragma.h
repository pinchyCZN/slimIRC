#pragma warning(disable:4013)
#pragma warning(disable:4047)
#pragma warning(disable:4024)